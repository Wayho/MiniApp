// miniprogram/pages/article/article.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      url:"",
      aUrl: ["http://mp.weixin.qq.com/s?__biz=MzU2MTY3MzMxOA==&mid=100000002&idx=1&sn=e960735a50399d1bf9ff137563f02d98&chksm=7c74640b4b03ed1d024f8055edcc3eca90adb085cc6ad9accbbb32c3a90550b542c8ee6da09f#rd",
      "http://mp.weixin.qq.com/s?__biz=MzU2MTY3MzMxOA==&mid=100000027&idx=1&sn=509302990e53640c371241973c604d44&chksm=7c7464124b03ed04e9b0858e5ba3285cbfbcf15a1d4d480663d7dcd1953c0b54b88cfcbb37d8#rd"
      ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
        let iUrlId = parseInt(options.urlid);
        console.log(iUrlId)
        this.setData({
            url: this.data.aUrl[iUrlId]
        })
        console.log(this.data.url)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})