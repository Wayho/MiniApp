//index.js
const AV = require('../../utils/av-live-query-weapp-min');
const app = getApp()
const db = wx.cloud.database()
const book = db.collection('message')

var message = '';

Page({
  data: {
      openid:'',
    avatarUrl: './user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
      //text: [{ message: "ASDF", sender: 0 }, { message: "A123", sender: 1 }, { message: "丹霞", sender: 0 }],
      text: [],
  },

    getUserInfo() {
        //wx.login({
        //    success:function(res){
        //        console.log(res)
        //    }
        //})
        // 获取用户信息
        wx.getUserInfo({
            success: function (res) {
                this.setData({
                    avatarUrl: res.userInfo.avatarUrl,
                    userInfo: res.userInfo
                })
            }
        })

        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
                console.log('[云函数] [login] : ', res)
                this.setData({
                    openid: res.result.openid
                })
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
            }
        })
    },

    bindChange: function (e) {
        message =  e.detail.value
    },

    pushmessage:function(msg,who){
        var newtext = this.data.text;
        newtext.push({ message: msg, sender: who })
        this.setData({
            text: newtext
        })
        //console.log(this.data.text)
        wx.cloud.callFunction({
            name: 'message_new',
            data: { sender:who, message: msg},
            success: res => {
                console.log('[云函数] [message_new] : ', res)
            },
            fail: err => {
                console.error('[云函数] [message_new] 调用失败', err)
            }
        })
    },

    send: function (e) {
        this.pushmessage(message,0);
        //this.pushmessage("MSF");
        //AV.Cloud.run('chat', message).then(console.log('chat')).catch(error => console.error(error.message));
        const paramsJson = { msg: message};
        var promise = AV.Cloud.run('chat', paramsJson);
        promise.then(data=> {
            // 调用成功，
            console.log(data);
            this.pushmessage(data,1);

        }).catch(error => console.error(error.message));
        //console.log(this.data.text)
    },

    send2: function (e) {
        //this.pushmessage(message);
        //this.pushmessage("MSF");
        //AV.Cloud.run('chat', message).then(console.log('chat')).catch(error => console.error(error.message));
        const paramsJson = { msg: message };
        AV.Cloud.run('chat', paramsJson).then(function (data) {
            console.log(data);
            this.pushmessage("DADA");

        }, function (err) {
            // 处理调用失败
            console.log(err);
        });

    },

    getmsg:function(){
        const paramsJson = { type: 2, page: 'pages/index/index', scene: '1058' };
        //const paramsJson = { type: 3,          path: 'pages/login/login',      };
        AV.Cloud.run('getwxacode', paramsJson).then(function (data) {
            // 调用成功，得到生成二维码的链接
            console.log(data.url);
        }, function (err) {
            // 处理调用失败
            console.log(err);
        });
    },

  onLoad: function() {
        this.getUserInfo();
        console.log(this.data);
        //return

      db.collection('message').where({
          _openid: this.data.openid
      })
          .get({
              success: res => {
                  console.log(res.data)
                  //o9vT94xFq9KgqCGPsc35QNpOblco
                  this.setData({
                      text: res.data
                  })
              }
          })

        db.collection('message').get({
            success: res => {
                console.log(res)
                //o9vT94xFq9KgqCGPsc35QNpOblco
                this.setData({
                    text: res.data
              })
          }
      })
  },

  onGetUserInfo: function(e) {
    if (!this.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },

})
