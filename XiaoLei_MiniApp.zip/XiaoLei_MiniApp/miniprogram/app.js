const AV = require('./utils/av-live-query-weapp-min');

AV.init({
    appId: 'eOUbmrxSphlHAzlx07atsD9K-gzGzoHsz',
    appKey: 'uk8EzKhqq8CEYMzSUyiBgHB5',
});
//app.js
App({
  onLaunch: function () {
    
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        traceUser: true,
      })
    }

    this.globalData = {}
  }
})
