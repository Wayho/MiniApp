// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

exports.main = async (event, context) => {
    return await db.collection('variable').doc('W68EM_D0YIt7pRhl').get()
}