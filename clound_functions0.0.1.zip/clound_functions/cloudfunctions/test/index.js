//https://cloud.tencent.com/document/product/583/14570
// 云函数入口文件
//const cloud = require('wx-server-sdk')

//cloud.init()


const rp = require('request-promise')

exports.main =  (event, context) => {
    return rp('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + process.env.APPID + '&secret=' + process.env.APPSECRET)
}