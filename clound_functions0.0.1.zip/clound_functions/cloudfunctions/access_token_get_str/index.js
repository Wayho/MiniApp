//获取 公众平台的 API 调用所需的 access_token
//https://cloud.tencent.com/document/product/583/14570
//https://mp.weixin.qq.com/debug/
//https://developers.weixin.qq.com/miniprogram/dev/api/token.html
//https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET
/*
https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx9bb741d1c937d3be&secret=30dec3a2745a0757c91966f503e6e571
{
        "APPID": "wx9bb741d1c937d3be",
        "APPSECRET": "30dec3a2745a0757c91966f503e6e571",
    }
}
*/

const rp = require('request-promise')
const cloud = require('wx-server-sdk')
cloud.init({})
const db = cloud.database()

const options = {
    uri: 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential',
    qs: {
        appid: process.env.APPID,               // -> uri + '?appid=xxxxx%20xxxxx'
        secret: process.env.APPSECRET
    },
    headers: {
        'User-Agent': 'Request-Promise'
    },
    json: true // Automatically parses the JSON string in the response
};

function update_access_token() {
    return rp(options)
        .then(res => {
            return res.access_token
        })
        .catch(err => {
            console.error("err", err)
            return "None"
        });
}

exports.main = async (event, context) => {
    return update_access_token()
}

/*
    //小程序端调用：
        wx.cloud.callFunction({
            name: 'access_token_get_str',
            data: { },
            success: res => {
                console.log('[getaccesstokenraw] [getaccesstoken] : ', typeof res.result, res.result)
            }
        })
*/