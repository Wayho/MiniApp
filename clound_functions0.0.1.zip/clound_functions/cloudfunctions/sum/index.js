// 云函数入口文件
//const cloud = require('wx-server-sdk')

//cloud.init()

// 云函数入口函数
// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  
  return {
    sum: event.a + event.b
  }
}

/*
console.log(res)
    return res.result.access_token

    const params = {
        scene: 'scene_abc_123',
        path: '/pages/index/index'
    };
    let url = 'https://api.weixin.qq.com/wxa/getwxacodeunlimit';

    // 3. 调用二维码生成接口获取二维码二进制流
    axios.post(url, params, {
        params: {
            access_token: res.result.access_token,
            dataType: 'JSON',
        },
        responseType: 'arraybuffer'
    }).then((res) => {
        // 4. 保存二维码到leancloud
        if (typeof res.data === 'undefined') {
            return response.error('生成二维码失败');
        } else {
            return res.data
        }
    });
*/