//https://developers.weixin.qq.com/miniprogram/dev/api/open-api/qr-code/getWXACodeUnlimit.html
// 云函数入口文件
//const cloud = require('wx-server-sdk')

//cloud.init()


var rp = require('request-promise')

exports.main = (event, context) => {
    console.log(event)
    console.log('context', context)
    //return event
    
    var url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token="+event.access_token;
    requireParams.push('page');
    requireParams.push('scene');

    axios.post(url, params, {
        params: {
            access_token: accessToken.accessToken,
            dataType: 'JSON',
        },
        responseType: 'arraybuffer'
    }).then((res) => {
        // 4. 保存二维码到leancloud
        if (typeof res.data === 'undefined') {
            return response.error('生成二维码失败');
        } else {
            const imageFile = new AV.File('file-qrcode.png', res.data);
            imageFile.save().then((res) => {
                return response.success(res);
            }, (error) => {
                return response.error(err);
            });
        }
    });

    console.log('access_token', res);
    return res
}