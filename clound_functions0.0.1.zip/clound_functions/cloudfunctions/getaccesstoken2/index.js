//获取 公众平台的 API 调用所需的 access_token
//https://mp.weixin.qq.com/debug/
//https://developers.weixin.qq.com/miniprogram/dev/api/token.html
//https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET
// 注意原请求返回JSON的RAW格式
/*
{
    "APPID": "wx9bb741d1c937d3be",
        "APPSECRET": "57dcc38048f41503b39d887b411f209d",
            "userInfo": {
        "appId": "wx9bb741d1c937d3be",
            "openId": "o1p9G4xtBJIDL5U4M7eUaC8qOxl8"
    }
}
*/
const rp = require('request-promise')

exports.main = async (event, context) => {
    //console.log(event)
    //console.log('context', context)
    let jsonstr = await rp('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + event.APPID + '&secret=' + event.APPSECRET)
    //return JSON.parse(jsonstr)
    return jsonstr
}

/*
    //小程序端调用：
    wx.cloud.callFunction({
            name: 'getaccesstoken',
            data: { 'APPID': 'wx9bb741d1c937d3be', 'APPSECRET': '57dcc38048f41503b39d887b411f209d' },
            success: res => {
                console.log('[云函数] [getaccesstoken] : ', res.result)
                app.globalData.access_token = res.result
                wx.navigateTo({
                    url: '../access_token/access_token',
                })
            },
            fail: err => {
                console.error('[云函数] [sum] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })
*/