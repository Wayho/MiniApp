//获取 公众平台的 API 调用所需的 access_token
//https://mp.weixin.qq.com/debug/
//https://developers.weixin.qq.com/miniprogram/dev/api/token.html
//https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET
// 注意原请求返回JSON的RAW格式
////云开发环境只能通过cloud.callFunction调用，否则无法处理转义
/*
https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx9bb741d1c937d3be&secret=30dec3a2745a0757c91966f503e6e571
{
    "APPID": "wx9bb741d1c937d3be",
        "APPSECRET": "30dec3a2745a0757c91966f503e6e571",
            "userInfo": {
        "appId": "wx9bb741d1c937d3be",
            "openId": "o1p9G4xtBJIDL5U4M7eUaC8qOxl8"
    }
}
*/
const rp = require('request-promise')

exports.main = async (event, context) => {
    return await rp('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + process.env.APPID + '&secret=' + process.env.APPSECRET)
}

/*
    //小程序端调用：
    wx.cloud.callFunction({
            name: 'getaccesstokenraw',
            data: {  },
            success: res => {
                console.log('[云函数] [getaccesstoken] : ', res.result)
                app.globalData.access_token = res.result
                wx.navigateTo({
                    url: '../access_token/access_token',
                })
            },
            fail: err => {
                console.error('[云函数] [sum] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })
*/