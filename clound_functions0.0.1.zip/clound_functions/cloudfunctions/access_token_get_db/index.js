//从access_token集合获取 公众平台的 API 调用所需的 access_token
//https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-server-api/database/doc.get.html
const cloud = require('wx-server-sdk')

cloud.init({})
const db = cloud.database()

exports.main = async (event, context) => {
    try {
        return await db.collection('variable').doc('access_token').get().then(res => {
            return res.data
        })
    } catch (e) {
        console.error(e)
    }
    
}
/*
return await db.collection('access_token').doc('W68EM_D0YIt7pRhl').get().then(res => {
        console.log(res.data)
        return res.data
    })
 */