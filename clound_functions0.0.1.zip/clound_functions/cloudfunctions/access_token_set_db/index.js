//向access_token集合写入所获取的 公众平台的 API 调用所需的 access_token
//https://developers.weixin.qq.com/miniprogram/dev/wxcloud/reference-server-api/database/doc.set.html
const cloud = require('wx-server-sdk')

cloud.init({})
const db = cloud.database()

exports.main = async (event, context) => {
    try{
        return await db.collection('variable').doc('access_token').set({
            data: {
                access_token: "AFASFDWAD",
                time: db.serverDate()
            }
        })
    } catch (e) {
        console.error(e)
    }
    
}