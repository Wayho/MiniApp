'use strict';

//Book1---- Chapter1---- Section11
//                                      Section12
//				                        Section13
//		            Chapter2----Section21
//				                        Section21
//		            Chapter3----Section31
var Gun = require('../');
//Chapter/Section/Part

var gun = Gun({
	file: 'localstorage.json', // Saves all data to `localstorage.json`.
});

	var Book = gun.get('Book1');
	Book.put({Title:'Book Title',Content:'Book Content'});

	var Chapter1 = gun.get('Chapter1').put({Title: "Chapter one", Content: "C1"});
	var Chapter2 = gun.get('Chapter2').put({Title: "Chapter two", Content: "C2"});
	var Chapter3 = gun.get('Chapter3').put({Title: "Chapter tree", Content: "C3"});

	Chapter1.get('farther').set(Book);
	Book.get('child').set(Chapter1);
	Chapter2.get('farther').set(Book);
	Book.get('child').set(Chapter2);
	Chapter3.get('farther').set(Book);
	Book.get('child').set(Chapter3);
	

	var Section11 = gun.get('Section11').set({Title: "Section 11", Content: "S11"});
	var Section12 = gun.get('Section12').set({Title: "Section 12", Content: "S12"});
	var Section13 = gun.get('Section13').set({Title: "Section 13", Content: "S13"});
	var Section21 = gun.get('Section21').set({Title: "Section 21", Content: "S21"});
	var Section22 = gun.get('Section21').set({Title: "Section 22", Content: "S22"});
	var Section31 = gun.get('Section31').set({Title: "Section 31", Content: "S31"});

	Chapter1.get('child').set(Section11);
	Section11.get('farther').set(Chapter1);
	Chapter1.get('child').set(Section12);
	Section12.get('farther').set(Chapter1);
	Chapter1.get('child').set(Section13);
	Section13.get('farther').set(Chapter1);

	Chapter2.get('child').set(Section21);
	Section21.get('farther').set(Chapter2);
	Chapter2.get('child').set(Section22);
	Section22.get('farther').set(Chapter2);

	Chapter3.get('child').set(Section31);
	Section31.get('farther').set(Chapter3);

	for(var i=0;i<30000;i++)
		var a=1
	
	Book.get('child').map().val(function(Chapter){
	  console.log("Book Chapter is", Chapter);
	});
	
	Chapter1.get('child').map().val(function(section){
	  console.log("Chapter1 child is", typeof section, section);
	});

	Chapter2.get('child').map().val(function(section){
	  console.log("Chapter2 child is", typeof section, section);
	});



/*
	var alice = gun.get('person/alice').put({name: 'alice', age: 22});
	var bob = gun.get('person/bob').put({name: 'bob', age: 24});
	var carl = gun.get('person/carl').put({name: 'carl', age: 16});
	var dave = gun.get('person/dave').put({name: 'dave', age: 42});

	

	var people = gun.get('people');
	people.set(alice);
	people.set(bob);
	people.set(carl);
	people.set(dave);

	people.map().val(function(person){
	  console.log("The person is", person);
	});

	people.map().get('name').val(function(person){
	  console.log("The person is", person);
	});

	

	dave.get('kids').set(carl);
	carl.get('dad').set(dave);

	carl.get('friends').set(alice);
	carl.get('friends').set(bob);

	dave.get('kids').map().val(function(person){
	  console.log("dave kids is", typeof person, person['name']);
	});


	carl.get('dad').map().val(function(person){
	  console.log("carl dad is", person['name']);
	});

	carl.get('friends').map().val(function(person){
	  console.log("carl friends is", person['name']);
	});



var Book = gun.get('Book1');
Book.put({Title:'Title1',Content:'Content1'});
gun.get('C1').put({name: "C1", species: "C1aa"});
gun.get('C2').put({name: "C2", species: "C2aa"});

Book.get('child').put('C1')
gun.get('C1').get('farther').put('Book1')

Book.get('child').put('C2')
gun.get('C2').get('farther').put('Book1')



var Book = gun.get('Book1');
Book.put({Title:'Title1',Content:'Content1'});
gun.get('Book1').put({name: "C1", species: "C1aa"});
gun.get('Book1').put({name: "C2", species: "C2aa"});
var C2 = Book.get('C2').put('C2');
Book.set(C2);

var cat = {name: "Fluffy", species: "kitty"};
var cat2 = {name: "c2", species: "c22"};
var mark = {slave: cat};
cat.boss = mark;
cat2.boss = mark;

// partial updates merge with existing data!
gun.get('mark').put(mark);

// access the data as if it is a document.
gun.get('mark').get('boss').get('name').val(function(data, key){
  // `val` grabs the data once, no subscriptions.
  console.log("Mark's boss is", data);
});

// traverse a graph of circular references!
gun.get('mark').get('boss').get('slave').once(function(data, key){
  console.log("Mark is the slave!", data);
});

// add both of them to a table!
gun.get('list').set(gun.get('mark').get('boss'));
gun.get('list').set(gun.get('mark'));

// grab each item once from the table, continuously:
gun.get('list').map().once(function(data, key){
  console.log("Item:", data);
});

// live update the table!
gun.get('list').set({type: "cucumber", goal: "scare cat"});

*/
//Book.set('T2');
//Book.set('T3');
//Book.set('T4');
//console.log('********',thoughts.map());
//thoughts.get('T1').set('T1');
//thoughts.get('T1').get('T11').put('T11');
//thoughts.get('T1').get('T12').put('T12');
//thoughts.get('T1').get('T11').get('T111').put('T111');
//thoughts.get('T2').put('T2');
//thoughts.get('T2').get('T21').put('T21');
//thoughts.put({Title:'Title1',Content:'Content1'});
//thoughts.put({Title:'Title2',Content:'Content2'});
//thoughts.put({Title:'Title3',Content:'Content3'});
//thoughts.get('key1').put({Title:'Title1',Content:'Content1'});
//thoughts.put('key2');
//thoughts.get('key2').put({Title:'Title2',Content:'Content2'});

