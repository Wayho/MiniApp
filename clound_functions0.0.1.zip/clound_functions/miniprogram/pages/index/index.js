//index.js
//const axios = require('axios')

const app = getApp()
const db = wx.cloud.database()

Page({
    data: {
        avatarUrl: './user-unlogin.png',
        userInfo: {},
        logged: false,
        takeSession: false,
        requestResult: ''
    },

    getUserInfo(){
      // 获取用户信息
      wx.getSetting({
          success: res => {
              if (res.authSetting['scope.userInfo']) {
                  // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
                  wx.getUserInfo({
                      success: res => {
                          this.setData({
                              avatarUrl: res.userInfo.avatarUrl,
                              userInfo: res.userInfo
                          })
                      }
                  })
              }
          }
      })
    },

    cloud_key(){
        console.log("cloud",wx.cloud)
    },

    log_login_add(){
        /*db.collection('access_token').add({
            data: {
                access_token: ":::",
                time: new Date().getTime()
            }
        })*/
        var str_json = JSON.stringify(this.data);
        console.log(this.data)
        return
        fs.writeFile('graph.json', str_json, 'utf8', function () {
            // 保存完成后的回调函数
            console.log("保存完成");
        });
        return
        db.collection('access_token').doc('W68rY5bUKA86qowJ').get({
            success: function (res) {
                console.log(res.data)
                return res.data
            },
            fail:function(err){
                console.log(err)
            }
        })
        return
        let getdoc = db.collection('access_token').doc('W68EM_D0YIt7pRhl').get().then(res => {
            console.log(res.data)
            return res.data
        })
        console.log(getdoc)

        return
        wx.cloud.callFunction({
            name: 'log_login_add',
            data: {},
            success: res => {
                console.log('[云函数] [log_login_add] : ', res)
                if (res.errMsg)
                    wx.showToast({
                        title: 'ok_login_add',
                    })
                else
                    wx.showToast({
                        title: 'fali_login_add',
                    })
            },
            fail: err => {
                console.error('[云函数] [log_login_add] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })
    },

    getaccesstoken() {
        wx.cloud.callFunction({
            name: 'access_token_get_str',
            data: { },
            success: res => {
                console.log('[getaccesstokenraw] [getaccesstoken] : ', typeof res.result, res.result)
            }
        })
        return
        wx.cloud.callFunction({
            name: 'test',
            data: {},
            success: res => {
                console.log('[test] [getaccesstoken] : ', typeof res.result, res.result)
                let jsonObject = JSON.parse(res.result);
                console.log('[test] [jsonObject] : ', typeof jsonObject, jsonObject)
            }
        })


    },

    getaccesstokenraw() {
        //let res = util.access_token({ 'APPID': 'wx9bb741d1c937d3be', 'APPSECRET': '57dcc38048f41503b39d887b411f209d' })
        wx.cloud.callFunction({
            name: 'getaccesstokenraw',
            data: { 'APPID': 'wx9bb741d1c937d3be', 'APPSECRET': '30dec3a2745a0757c91966f503e6e571' },
            success: res => {
                console.log('[云函数] [getaccesstoken] : ', res.result)
                let jsonObject = JSON.parse(res.result); 
                for (let key in jsonObject) {
                    if (key =="access_token"){
                        console.log("access_token OK",key)
                        console.log('[云函数] [access_token] : ', jsonObject.access_token)
                        app.globalData.access_token = jsonObject.access_token
                    }
                }
            },
            fail: err => {
                console.error('[云函数] [sum] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })

    },

    getQrCode() {
        //let res = util.access_token({ 'APPID': 'wx9bb741d1c937d3be', 'APPSECRET': '57dcc38048f41503b39d887b411f209d' })
        wx.cloud.callFunction({
            name: 'getwxacodeunlimit',
            data: { 'scene': 'asdf123456'},
            success: res => {
                console.log('[getwxacodeunlimit] [res] : ', res)
                console.log('[getwxacodeunlimit] [res.data] : ', res.data)
                //console.log('[getwxacodeunlimit] [res.data.path] : ', res.data.path)
                
            },
            fail: err => {
                console.error('[云函数] [getwxacodeunlimit] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })

    },

    

    onLoad: function () {
        if (!wx.cloud) {
            wx.redirectTo({
                url: '../chooseLib/chooseLib',
            })
            return
        }
        this.getUserInfo()
        
        //this.cloud_key();
        //this.log_login_add()
        this.getaccesstoken()
        //this.getQrCode()
        //console.log(keyof(this.data))
        return
        let str = "{\"access_token\":\"14_u4-KAfifmHk8dRKFInVSUK7Uw6CjGqPT751EYCayuaRsaSL1fUYS0G6U9HHEx3cPREr1CQwYc_HyWZT4ByHxc8ykHvdRY7CMIeikthrPRv4mMcVRBajj_YzgodqHCxhiH6LaZwQ9JSLJnQJcSYNbAAAWCR\",\"expires_in\":7200}"
        //str.replace('\\','')
        var json = JSON.stringify(str)
        console.log(json)
        var jss = JSON.parse(json)
        console.log(jss)
        var ja = JSON.parse(json)
        console.log(ja)
        //this.getQrCode()
        wx.showShareMenu({
            withShareTicket: true
        })
    },

    onShareAppMessage: function () {
        return {
            title: '自定义转发标题',
            path: '/index/index?ref=abc123',
            success: function (res) {
                var shareTickets = res.shareTickets;
                if (shareTickets.length == 0) {
                    return false;
                }
                console.log(shareTickets);
                
            },
            fail: function (res) {
                // 转发失败
            }
        }
    },

    onGetUserInfo: function (e) {
        if (!this.logged && e.detail.userInfo) {
            this.setData({
                logged: true,
                avatarUrl: e.detail.userInfo.avatarUrl,
                userInfo: e.detail.userInfo
            })
        }
    },

    onGetOpenid: function () {
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
                console.log('[云函数] [login] user openid: ', res.result.openid)
                app.globalData.openid = res.result.openid
                wx.navigateTo({
                    url: '../userConsole/userConsole',
                })
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })
    },

    onSum: function () {
        // 调用云函数
        wx.cloud.callFunction({
            name: 'sum',
            data: { 'a': 123, 'b': 456 },
            success: res => {
                console.log('[云函数] [sum] sum: ', res.result.sum)
                app.globalData.sum = res.result.sum
                wx.navigateTo({
                    url: '../sum/sum',
                })
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })
    },

    onGetAccessToken: function () {

        // 调用云函数
        /* wx.cloud.callFunction({
           name: 'getaccesstoken',
           data: { 'APPID': 'wx9bb741d1c937d3be', 'APPSECRET': '57dcc38048f41503b39d887b411f209d' },
           success: res => {
             console.log('[云函数] [onGetAccessToken] : ', res.result)
             app.globalData.access_token = res.result
             wx.navigateTo({
               url: '../access_token/access_token',
             })
           },
           fail: err => {
             console.error('[云函数] [sum] 调用失败', err)
             wx.navigateTo({
               url: '../deployFunctions/deployFunctions',
             })
           }
         })*/
    },

    // 上传图片
    doUpload: function () {
        // 选择图片
        wx.chooseImage({
            count: 1,
            sizeType: ['compressed'],
            sourceType: ['album', 'camera'],
            success: function (res) {

                wx.showLoading({
                    title: '上传中',
                })

                const filePath = res.tempFilePaths[0]

                // 上传图片
                const cloudPath = 'my-image' + filePath.match(/\.[^.]+?$/)[0]
                wx.cloud.uploadFile({
                    cloudPath,
                    filePath,
                    success: res => {
                        console.log('[上传文件] 成功：', res)

                        app.globalData.fileID = res.fileID
                        app.globalData.cloudPath = cloudPath
                        app.globalData.imagePath = filePath

                        wx.navigateTo({
                            url: '../storageConsole/storageConsole'
                        })
                    },
                    fail: e => {
                        console.error('[上传文件] 失败：', e)
                        wx.showToast({
                            icon: 'none',
                            title: '上传失败',
                        })
                    },
                    complete: () => {
                        wx.hideLoading()
                    }
                })

            },
            fail: e => {
                console.error(e)
            }
        })
    },

})
