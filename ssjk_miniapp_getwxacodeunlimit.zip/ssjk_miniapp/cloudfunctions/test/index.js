//https://developers.weixin.qq.com/miniprogram/dev/api/open-api/qr-code/getWXACodeUnlimit.html
// 云函数入口文件
//const cloud = require('wx-server-sdk')

//cloud.init()


var rp = require('request-promise')

exports.main = (event, context) => {
    console.log(event)
    console.log('context', context)
    //return event

    var url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + event.access_token;

    axios.post(url, {
        "scene": event.scene,
        "page": "pages/index/index",
    },{
        headers: {
            "Content-Type": "application / x - www - form - urlencoded"
        },
        responseType: 'arraybuffer'
    }).then((res) => {
        // 4. 保存二维码到leancloud
        if (typeof res.data === 'undefined') {
            return response.error('生成二维码失败');
        } else {
            return res.data
            //const imageFile = new AV.File('file-qrcode.png', res.data);
            //imageFile.save().then((res) => {
            //    return response.success(res);
            //}, (error) => {
            //    return response.error(err);
            //});
        }
    });

}