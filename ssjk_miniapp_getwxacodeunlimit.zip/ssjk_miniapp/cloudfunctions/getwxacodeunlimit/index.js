//https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx9bb741d1c937d3be&secret=30dec3a2745a0757c91966f503e6e571 
//https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=14_eQUZLpfreMGp0mSvbdRZH5g5ajHNpWUFmpFMvY-VJBIXjoVBGzwuNtCcSL7qjFODE9xSkL-Rw4pbAC-DoWRnMpRsVdXY45hcubwiCajS7a-rJU2jWyAVi6vcKAg5n3ZizLJqOLM4B6RcjqlaVIQaABAKXF

/*
{
    "scene": "abc1234567890",
    "page": "pages/index/index"
}
*/ 

//const cloud = require('wx-server-sdk')

//cloud.init({})
const rp = require('request-promise')
//const axios = require('axios');

exports.main = async (event, context) => {
    let access_token = "14_yxLvj9XAgVCA4teEBM1gvCmN-IffBN1kjWsBjTRiuarPiexxX8-CkubpXvNmGUVAo9U9PxhjQh4EOb2CS37qhsNY_unysIaGpjiwxF4Lw4otwCGx3NkRXhnP5hBgEAD-pqUMap5PBb9CvAc8MMWgAFAWWG";
    console.log(access_token)
    //return access_token
    let url = 'https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=' + access_token;
    var options = {
        method: 'POST',
        uri: url,
        body: {
            "scene": event.scene,
            "page": "pages/index/index"
        },
        json: true // Automatically stringifies the body to JSON
    };
    //let jsonstr = await rp('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' )
    //return JSON.parse(jsonstr)
   // return jsonstr

    return await rp(options);



}