Component({
  options: {
    addGlobalClass: true
  },

  externalClasses: ['custom-class'],

  properties: {
    border: {
      type: Boolean,
      value: true
    }
  }
});
